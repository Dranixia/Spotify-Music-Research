from distutils.core import setup


setup(name="Genre Research Program",
      version="1.0",
      author="Butynets' Danylo",
      license="MIT",
      author_email="dranixoverlord@gmail.com",
      py_modules=["__init__"],
      packages=['example', 'docs', "modules"],
      data_files=[('docs', ['docs/results.json']), ('docs', ['docs/example.json']),
                  ('docs', ['docs/adt_test_example.json'])],
      install_requires=["bs4", "plotly", "spotipy"],
      scripts=['main.py'])
